#include "pila.h"

int main (void)
{

  C_pila<int> vpila;
  C_base<int> *pBase;

  pBase = &vpila;

  for (int i=100; i<110; ++i)
  {
  	pBase->agregar(i);
  }

  cout<<"Numero de elementos en la pila "<< pBase->count()<<endl;

  cout << "Se invierte la pila" << endl;

  pBase->invert();

  cout <<"\nResultado para la pila"<<endl;
  pBase->mostrar();

  cout << "Se vacia la pila" << endl;
  pBase->clear();

  cout << "\nSe rellena la pila con nuevos datos" << endl;
  for (int i=1; i<11; ++i)
  {
  	pBase->agregar(i);
  }

  cout <<"\nResultado para la pila"<<endl;
  pBase->mostrar();

}
