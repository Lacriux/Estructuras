/*********************************************************************
*
C_base.h
*********************************************************************
*/
#include<string>
#include<iostream>

using namespace std;

#ifndef CLASEBASE
#define CLASEBASE

template <typename T>
struct S_celda{
	T dato;
	S_celda *proximo;
};

template <typename T>
class C_base {
	protected:
		S_celda<T>* primer_elemento;
	public:
	C_base(void);
		virtual ~C_base(void){
			cout << "Destructor de base" << endl;
		}
		virtual bool agregar(T){
			return false;
		}
		virtual T quitar(void){
			return 0;
		}
		void clear(void){
			S_celda<T> *paux;
			paux=this->primer_elemento;
			while(this->primer_elemento != NULL){
				paux=this->primer_elemento;
		 		this->primer_elemento=paux->proximo;
		 		delete paux;
			}
			this->primer_elemento = NULL;
		}

		void invert(void){
				S_celda<T> *paux, *paux2;
				paux2 = this->primer_elemento;
				this->primer_elemento = this->primer_elemento->proximo;
				paux = this->primer_elemento;
				paux2->proximo = NULL;
				while(this->primer_elemento!=NULL){
					this->primer_elemento = this->primer_elemento->proximo;
					paux->proximo = paux2;
					paux2 = paux;
					paux = this->primer_elemento;
				}
				this->primer_elemento=paux2;
		}

		int count(void){
			S_celda<T> *paux;
			paux = this->primer_elemento;
			int cont = 0;
			while(paux!=NULL){
				paux=paux->proximo;
				cont++;
			}
			return cont;
		}

		void mostrar(void){
			S_celda<T> *paux;
			paux = this->primer_elemento;
			int i = 1;
			while(paux!=NULL){
				cout << i <<"-) " << paux->dato << endl;
				paux = paux->proximo;
				i++;
			}
		}

};

template <typename T>
C_base<T>::C_base(void)
{
	this->primer_elemento=NULL;
}
#endif
