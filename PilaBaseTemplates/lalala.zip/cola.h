/*********************************************************************
*
C_cola.h
*********************************************************************
*/

#include "base.h"

#ifndef CLASEcola
#define CLASEcola

template <typename T>
class C_cola : public C_base<T>{
	protected:
		S_celda<T> *ultimo_elemento;
	public:
		C_cola(void);
		~C_cola(void);
		bool agregar(T);
		T quitar(int);
};

template <typename T>
C_cola::C_cola(void) : C_base()
{
	ultimo_elemento = NULL;
}

C_cola::~C_cola(void)
{
   cout << "Destructor de cola" << endl;
   while(this->primer_elemento != NULL)
   	quitar();
}

template <typename T>
bool C_cola::agregar(T mi_dato, int pos)
{
	S_celda<T> *paux, *paux2;
	paux = new S_celda<T>;
	int cont = 1;
	int size;

	size = this->count();

	paux->dato=mi_dato;
	paux2 = this->primer_elemento;

	if(size < pos){
		cout<<"ERROR: El tamaño de la cola es menor a la posicion deseada"<<endl;
	}

	else{
		while(cont!=pos){
			paux2 = paux2->proximo;
			cont++;
		}
		paux->proximo = paux2->proximo;
		paux2->proximo = paux;
	}

	return true;
}

template <typename T>
int C_cola::quitar(int pos)
{
	T tdato;
	S_celda<T> *paux, *paux2;
	int cont = 1, size;
	size = this->count();

	paux = this->primer_elemento;
	paux2 = paux->proximo;

	if(size < pos){
		cout<<"ERROR: El tamaño de la cola es menor a la posicion deseada"<<endl;
	}
	else{
		for(int i = 1, i < pos-2; i++){
			paux = paux->proximo;
		}
		paux2 = paux->proximo;
	}
	return tdato;
}
#endif
